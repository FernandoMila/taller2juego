package presentacion;

import presentacion.MainWindow;

public class JuegoCarmenSandiego {

    public static void main(String[] args) {
        // Crear y mostrar la ventana
        new MainWindow();
    }
}
